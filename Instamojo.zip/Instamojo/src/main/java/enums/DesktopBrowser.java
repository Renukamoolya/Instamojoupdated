package enums;

public enum DesktopBrowser {
	IE, EDGE, CHROME, SAFARI, FIREFOX
}
