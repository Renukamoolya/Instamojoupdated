package enums;

public enum IdentificationPlatform {
	IOS, ANDROID, MWEB, DESKTOP_WEB
}
